# 可直接粘贴给网页端的任务

请阅读上传 ZIP 中所有 Markdown、实机 JSON 和上游接口摘录，为 NanoPC-T6 LTS / RK3588 / Armbian Debian 13 编写一份可构建、可部署、可审查的 IP-KVM 初版源码，返回源码 ZIP。

用户已拥有 PiKVM，实际只使用 TigerVNC 直连其 VNC 服务，并满意这种操作方式。保留 TigerVNC。优先复用 pikvm/kvmd 的 kvmd-vnc、认证和 USB HID 控制，在 Rockchip 侧实现必要的 HDMI RX + MPP 视频适配。不要自行重写整个 RFB 协议，不要改成仅支持网页/WebRTC，不要用 X11 桌面播放视频再 x11vnc 翻拍。保留内部 HTTP/WebSocket API 是允许的，不要求提供 Web UI。

分辨率目标为 2560×1440@60；先提供可工作的 1920×1080 档位。实机证据未证明原生 1440p，禁止将其写成已实测能力。EDID 和驱动时序限制见 DEVICE_BOUNDARIES.md。提供原生输入探测和失败诊断；可以设计显式可选的 4K→1440p 缩放，但不能隐式降为 1080p 后冒充 2K。

请先核对并固定 kvmd、ustreamer、Rockchip MPP/RGA 的实际版本/提交与许可证。实现最小改动：优先复用现有 memsink 协议；若不适合，提供独立 streamer client 和小型适配补丁，并说明 kvmd 的状态、参数控制和生命周期接口如何满足。不能只写一个把 H.264 写到 stdout 的演示就称为完成。不要假设官方 ustreamer 原生支持本设备的 MPP 后端。

交付必须包含：源码、固定依赖/构建说明、示例配置、只读 preflight、显式安装/卸载/回滚脚本、systemd 单元、硬件验收步骤及结果模板。能够完成的协议/生命周期测试应可在无硬件环境执行；硬件测试标为待验证。不要编造跑通结果、帧率、延迟或不存在的 API。若无法一次实现全部内容，明确列出真正实现的功能与阻塞项，不能用 TODO stub 冒充工作实现。

设备仍承载其他业务：不能重刷系统、改内核、重启、替换网络/防火墙/代理、停止现有容器、覆盖现有 USB Gadget。EDID 修改、内核修改和 Gadget 接管必须是显式可选操作。任何部署先检查资源占用；本次任务只写代码，不远程部署。

请按 ARCHITECTURE.md 和 ACCEPTANCE.md 的要求设计，尤其处理 H.264 关键帧恢复、断线释放按键、分辨率改变与认证后单客户端接管。
