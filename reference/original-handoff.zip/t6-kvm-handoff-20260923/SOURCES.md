# 来源与可信度

实机证据：evidence/video-probe.json（本轮只读 ioctl）、evidence/inventory.txt（本轮 OS、资源、端口与包查询）。tools/probe_video.py 为可重新执行的只读探测脚本，仅适用于本设备 Linux little-endian 64-bit ABI；不是跨平台库。

官方硬件文档：https://wiki.friendlyelec.com/wiki/index.php/NanoPC-T6
PiKVM VNC 文档：https://docs.pikvm.org/vnc/
kvmd：https://github.com/pikvm/kvmd
uStreamer：https://github.com/pikvm/ustreamer
Rockchip MPP：https://github.com/rockchip-linux/mpp
Rockchip RGA：https://github.com/airockchip/librga

同系列驱动参考（不是运行内核精确构建证明）：
https://github.com/armbian/linux-rockchip/blob/rk-6.1-rkr5.1/drivers/media/platform/rockchip/hdmirx/rk_hdmirx.c
https://github.com/armbian/linux-rockchip/blob/rk-6.1-rkr5.1/drivers/media/v4l2-core/v4l2-dv-timings.c

One-KVM 当前 README 描述 Rust 主线、RK3588 HDMI IN/RKMPP，旧 Python 分支停止开发；README 未声明 VNC，不能假设它能直接满足 TigerVNC。可参考视频后端，不直接替换用户工作流。https://github.com/mofeng-git/One-KVM

上游可变分支快照在 evidence/upstream/，仅供接口审查，构建时须重新固定真实 commit 并保留上游许可证。
