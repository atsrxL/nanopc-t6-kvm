# 设备能力与边界

## 本轮实机验证
- 目标：FriendlyElec NanoPC-T6 LTS，RK3588，aarch64；LAN 192.168.123.99。
- 系统：Armbian 26.5.1 trixie / Debian 13.5；内核 6.1.115-vendor-rk35xx。
- 内存约 15 GiB；本轮可用约 7 GiB。根分区剩余约 49 GiB，/nvme 剩余约 308 GiB。资源为瞬时观测，部署前重新检查。
- HDMI RX：/dev/video0，VIDEO_CAPTURE_MPLANE 格式 BGR3 / NV24 / NV16 / NV12。不能按普通 USB UVC 单平面设备硬编码。
- V4L2 时序能力：640..4096 × 480..2160，像素时钟 20..600 MHz；standards=1（CEA861），flags=3（progressive + interlaced），未宣告 CUSTOM 或 reduced blanking。
- 枚举包含 1080p60、3840×2160p60 等；没有 2560×1440。枚举上限不是实际成功采集证明。
- 当前 QUERY_DV_TIMINGS 返回 ENOLINK：无有效信号，未做采集/编码/键鼠/延迟实测。
- 读到两块 EDID，基础详细时序有 1080p60、720p60，未发现明确 1440p 声明。原始 EDID 在 evidence 中，仅作为当前快照，不能当通用模板覆盖其他设备。
- /dev/mpp_service 和 /dev/rga 存在，但权限 root:root 0600。节点存在不证明用户态编码库可用。
- gcc 可用；本轮 PATH 未找到 ffmpeg、gst-launch-1.0、v4l2-ctl。包查询未找到已安装的专用 MPP/Rockchip/kvmd/ustreamer 软件包；不排除手动安装的库，preflight 需检查 ldconfig/pkg-config。

## 同会话前次实机证据
- /sys/class/udc/fc000000.usb，state=not attached，function 为空。未发现已绑定 Gadget；部署时必须重新检查。
- 内核 CONFIG_USB_CONFIGFS_F_HID=y、MASS_STORAGE=y、LIBCOMPOSITE=y。
- HDMI 音频 ALSA 设备 rockchiphdmiin 存在；音频非本项目首版目标。
- USB 总线只看到根 Hub 和一个四口 USB2 Hub，未枚举出外接终端；不能据此证明物理接口一定空着。

## 物理接口（官方文档）
HDMI IN 不占 USB。全功能 USB-C 用作 USB Device/Gadget 连被控电脑；不要误用 USB-C 调试串口。仍保留 1×USB-A 3.0 + 2×USB-A 2.0 Host，10-pin 排针还有两路 USB2 Host 可引出，M.2 E-Key 有 USB2。独立 DC 供电，避免默认依赖被控电脑 USB 供电。主板版本/外壳开孔应现场核对。HDMI OUT 不是自动直通。

## 1440p 的关键风险
官方标称 HDMI 输入最高 4K60，1440p60 吞吐量低于此上限，但不等于任意时序都支持。同系列 Armbian rk-6.1-rkr5.1 源码的 hdmirx_s_dv_timings 会匹配 CEA 预设，可能拒绝 PC/CVT 的 1440p。该源码不是本机精确构建来源证明，只用于解释风险；必须找到运行内核对应源码或实测后定论。仅添加 EDID 不能保证消除此限制。

优先原生 1440p 的受控验证；若必须改内核，不在默认安装流程执行。备选 4K 输入 + RGA 缩放为 1440p，应清晰标出输入/输出分辨率，说明细字缩放损失。不得承诺高刷、HDR、10bit、HDCP 输入。首版按 SDR 8bit H.264 4:2:0。

## 共存边界
80、8554、8555、7765 等端口已被业务占用，完整本轮端口在 evidence/inventory.txt。5900 本轮未见监听，但部署前须重新检测。不要占用 80 或抢占任何既有端口。
不改变当前网络、Docker 服务、内核或既有 PiKVM。部署到独立目录和独立服务，日志轮转。权限优先专用服务账号+明确设备授权，不用 chmod 777；若原型需要 root，明确局限。默认不创建 privileged Docker 全设备映射。
任何设备配置备份放目标机 /root/agent.backup/，每项最多保留两份已确认由本项目创建的备份；不得清理用户原有文件。
