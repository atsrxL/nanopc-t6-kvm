# 推荐架构与接口要求

视频：HDMI RX → V4L2 多平面采集 → 可选 RGA 色彩转换/缩放 → MPP H.264 → memsink 或专用 streamer adapter → kvmd-vnc → TigerVNC。
控制：TigerVNC → kvmd-vnc → kvmd 内部 API/WebSocket → USB HID Gadget → 被控电脑。

复用 kvmd 和 kvmd-vnc；只写必要的视频后端/适配。kvmd-vnc 是 kvmd 仓库的组成部分，不是只接受裸流的通用独立守护进程。保留必要内部 API，默认仅 Unix socket/loopback，Web UI 和 Janus/WebRTC 非必需。

## 必须做出的具体工程决策
1. 固定依赖提交；核对 memsink ABI、帧头、同步/锁、容量和 key-required 机制，不能凭字段名称猜实现。上游快照仅供阅读。
2. 采集遵循实际 QUERY_DV_TIMINGS、G_FMT、plane 数、bytesperline、sizeimage；NV12 不代表一定紧密排列。优先 DMA-BUF，无法零拷贝时明确拷贝次数和性能代价。
3. H.264 输出需要兼容 kvmd-vnc/TigerVNC 的 access unit 封装；接收端可从 SPS/PPS + IDR 开始解码。新连接、分辨率变化、流重启都可请求关键帧。编码级别根据实际 1440p60 需求选取，不硬编码只够 1080p 的 Level 4.1。
4. 低延迟配置禁用不必要重排，控制缓冲。不能任意丢参考 P 帧后继续发送依赖它的帧；溢出时重新同步 IDR。
5. 明确实现 kvmd 视频状态/参数接口和进程生命周期，否则只喂 memsink 不一定可用。支持无信号状态、SOURCE_CHANGE、重新申请 buffer、重新配置 encoder。
6. HID 使用稳定报告描述符和 BIOS 可用键盘，验证鼠标绝对坐标映射；断连/服务退出释放所有按键和按钮。USB Gadget 操作为独立显式步骤，遇到现有 UDC 占用立即停下并诊断，不覆盖。
7. 单客户端接管是建议保留的历史偏好：新连接认证成功后再关闭旧连接，错误密码和端口探测不应踢人；提供配置开关。
8. TigerVNC 具体构建和 H.264 能力待实机确认。日志必须显示实际协商编码；提供清楚的无 H.264 诊断或显式 Tight/JPEG fallback，不静默声称硬编正在工作。

## 首版范围
包含：VNC 视频、键鼠、认证、重连、基础状态日志、分辨率变化、可回滚部署。
可后续增加：虚拟媒体、ATX、音频。不要为了这些扩张首版范围。
可调配置：设备路径、VNC 监听地址/端口、目标帧率、码率、GOP、输入/输出模式、接管策略。1440p60 可从 20–35 Mbps 的实验档位开始，非已验证推荐或性能承诺。

现有 PiKVM 历史补丁包括 SetEncodings 重复协商缓存和新连接接管，但闪烁问题未完成端到端验收。不要照搬旧版本 server.py；先与选定上游比较，再用最小补丁实现必要行为。
