#!/usr/bin/env python3
"""Read-only Linux V4L2 probe. No format/EDID writes or streaming."""
import ctypes
import fcntl
import json
import os
import struct

def ioctl_code(direction, number, size):
    return (direction << 30) | (size << 16) | (ord('V') << 8) | number

def timing(buf, offset=0):
    w,h,interlaced,polarity,clock,hfp,hs,hbp,vfp,vs,vbp = struct.unpack_from('<IIIIQIIIIII',buf,offset+4)
    total=(w+hfp+hs+hbp)*(h+vfp+vs+vbp)
    return dict(width=w,height=h,interlaced=bool(interlaced),pixelclock=clock,progressive_fps=round(clock/total,3) if total and not interlaced else None)

fd=os.open('/dev/video0',os.O_RDONLY|os.O_NONBLOCK)
result={}
for label,n,size,direction in [('capabilities',100,144,3),('current_input',99,132,2)]:
    b=bytearray(size)
    try:
        fcntl.ioctl(fd,ioctl_code(direction,n,size),b)
        if n==100:
            vals=struct.unpack_from('<IIIIQQII',b,16)
            result[label]=dict(zip(['min_width','max_width','min_height','max_height','min_pixelclock','max_pixelclock','standards','flags'],vals))
        else: result[label]=timing(b)
    except OSError as e: result[label]=str(e)
result['enumerated_timings']=[]
for i in range(256):
    b=bytearray(148);struct.pack_into('<I',b,0,i)
    try: fcntl.ioctl(fd,ioctl_code(3,98,148),b)
    except OSError as e:
        result['timing_enumeration_end']=str(e);break
    result['enumerated_timings'].append(timing(b,16))
result['formats']=[]
for i in range(32):
    b=bytearray(64);struct.pack_into('<II',b,0,i,9)
    try: fcntl.ioctl(fd,ioctl_code(3,2,64),b)
    except OSError: break
    result['formats'].append(bytes(b[44:48]).decode())
edid=ctypes.create_string_buffer(32768)
b=bytearray(40);struct.pack_into('<III',b,0,0,0,256);struct.pack_into('<Q',b,32,ctypes.addressof(edid))
try:
    fcntl.ioctl(fd,ioctl_code(3,40,40),b)
    blocks=struct.unpack_from('<I',b,8)[0];data=edid.raw[:blocks*128]
    result['edid_blocks']=blocks;result['edid_hex']=data.hex();result['base_edid_detailed_timings']=[]
    for off in [54,72,90,108]:
        d=data[off:off+18]
        if len(d)!=18 or not (d[0] or d[1]): continue
        clk=int.from_bytes(d[:2],'little')*10000
        w=d[2]+((d[4]>>4)<<8);hb=d[3]+((d[4]&15)<<8)
        h=d[5]+((d[7]>>4)<<8);vb=d[6]+((d[7]&15)<<8)
        result['base_edid_detailed_timings'].append(dict(width=w,height=h,pixelclock=clk,fps=round(clk/((w+hb)*(h+vb)),3)))
except OSError as e: result['edid_error']=str(e)
os.close(fd)
print(json.dumps(result,indent=2))
